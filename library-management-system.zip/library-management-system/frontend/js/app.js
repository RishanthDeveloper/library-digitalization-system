const App = {
  API_BASE: localStorage.getItem('librisync_api_base') || 'http://localhost:3000/api',

  state: {
    books: [],
    members: [],
    transactions: [],
    activities: []
  },

  editing: { bookId: null, memberId: null },

  async init() {
    this.initNav();
    this.initClock();
    this.initTheme();
    this.initForms();
    document.getElementById('apiBaseInput').value = this.API_BASE;
    await this.refreshAll();
  },

  // ---------- API helpers ----------
  async apiGet(path) {
    const res = await fetch(`${this.API_BASE}${path}`);
    if (!res.ok) throw new Error((await res.json()).error || 'Request failed');
    return res.json();
  },
  async apiPost(path, body) {
    const res = await fetch(`${this.API_BASE}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  },
  async apiPut(path, body) {
    const res = await fetch(`${this.API_BASE}${path}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  },
  async apiDelete(path) {
    const res = await fetch(`${this.API_BASE}${path}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  },

  async refreshAll() {
    try {
      const [books, members, transactions, activities, stats] = await Promise.all([
        this.apiGet('/books'),
        this.apiGet('/members'),
        this.apiGet('/transactions'),
        this.apiGet('/activities'),
        this.apiGet('/dashboard/stats')
      ]);
      this.state.books = books;
      this.state.members = members;
      this.state.transactions = transactions;
      this.state.activities = activities;
      this.renderDashboard(stats);
      this.renderBooks();
      this.renderMembers();
      this.renderCirculation();
      this.renderActivityLog();
    } catch (err) {
      this.showToast(`Could not reach backend: ${err.message}`, 'error');
    }
  },

  // ---------- Navigation ----------
  initNav() {
    document.querySelectorAll('.nav-item').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.nav-item').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.view').forEach((v) => v.classList.add('hidden'));
        document.getElementById(`view-${btn.dataset.view}`).classList.remove('hidden');
        document.getElementById('viewTitle').textContent = btn.textContent;
      });
    });
  },

  initClock() {
    const tick = () => {
      document.getElementById('clock').textContent = new Date().toLocaleString();
    };
    tick();
    setInterval(tick, 1000);
  },

  initTheme() {
    const dark = localStorage.getItem('librisync_dark') === 'true';
    document.body.classList.toggle('dark', dark);
    document.getElementById('themeToggle').addEventListener('click', () => {
      const isDark = document.body.classList.toggle('dark');
      localStorage.setItem('librisync_dark', isDark);
    });
  },

  // ---------- Dashboard ----------
  renderDashboard(stats) {
    document.getElementById('statTotalBooks').textContent = stats.totalBooks;
    document.getElementById('statAvailable').textContent = stats.availableBooks;
    document.getElementById('statMembers').textContent = stats.activeMembers;
    document.getElementById('statOverdue').textContent = stats.overdueBooks;
    document.getElementById('statFines').textContent = `₹${stats.pendingFines}`;

    const list = document.getElementById('dashboardActivity');
    list.innerHTML = this.state.activities.slice(0, 5).map(this.activityItemHtml).join('');
  },

  activityItemHtml(a) {
    return `<li>${a.title}<span class="time">${new Date(a.time).toLocaleString()}</span></li>`;
  },

  renderActivityLog() {
    document.getElementById('fullActivityList').innerHTML =
      this.state.activities.map(this.activityItemHtml).join('');
  },

  // ---------- Books ----------
  renderBooks(filter = '') {
    const q = filter.toLowerCase();
    const rows = this.state.books
      .filter((b) => !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q) || (b.isbn || '').includes(q))
      .map((b) => `
        <tr>
          <td>${b.id}</td><td>${b.title}</td><td>${b.author}</td><td>${b.category || ''}</td><td>${b.rack || ''}</td>
          <td><span class="badge badge-${b.status.toLowerCase()}">${b.status}</span></td>
          <td>
            <button class="icon-btn" onclick="App.openBookModal('${b.id}')">✏️</button>
            <button class="icon-btn" onclick="App.deleteBook('${b.id}')">🗑️</button>
          </td>
        </tr>`).join('');
    document.getElementById('booksTableBody').innerHTML = rows || '<tr><td colspan="7">No books found</td></tr>';
  },

  openBookModal(id) {
    this.editing.bookId = id || null;
    const book = id ? this.state.books.find((b) => b.id === id) : null;
    document.getElementById('bookModalTitle').textContent = book ? 'Edit Book' : 'Add Book';
    document.getElementById('bookIdField').value = book ? book.id : '';
    document.getElementById('bookTitle').value = book ? book.title : '';
    document.getElementById('bookAuthor').value = book ? book.author : '';
    document.getElementById('bookIsbn').value = book ? book.isbn : '';
    document.getElementById('bookCategory').value = book ? book.category : '';
    document.getElementById('bookPublisher').value = book ? book.publisher : '';
    document.getElementById('bookYear').value = book ? book.year : '';
    document.getElementById('bookRack').value = book ? book.rack : '';
    document.getElementById('bookModal').classList.remove('hidden');
  },

  async saveBook(e) {
    e.preventDefault();
    const id = document.getElementById('bookIdField').value;
    const payload = {
      title: document.getElementById('bookTitle').value,
      author: document.getElementById('bookAuthor').value,
      isbn: document.getElementById('bookIsbn').value,
      category: document.getElementById('bookCategory').value,
      publisher: document.getElementById('bookPublisher').value,
      year: parseInt(document.getElementById('bookYear').value) || null,
      rack: document.getElementById('bookRack').value,
      status: 'Available',
      cover_url: ''
    };
    try {
      if (id) {
        await this.apiPut(`/books/${id}`, payload);
        this.showToast('Book updated', 'success');
      } else {
        payload.id = `BK-${Date.now().toString().slice(-6)}`;
        await this.apiPost('/books', payload);
        this.showToast('Book added', 'success');
      }
      document.getElementById('bookModal').classList.add('hidden');
      await this.refreshAll();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  async deleteBook(id) {
    if (!confirm('Delete this book?')) return;
    try {
      await this.apiDelete(`/books/${id}`);
      this.showToast('Book deleted', 'success');
      await this.refreshAll();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // ---------- Members ----------
  renderMembers(filter = '') {
    const q = filter.toLowerCase();
    const rows = this.state.members
      .filter((m) => !q || m.name.toLowerCase().includes(q) || m.email.toLowerCase().includes(q))
      .map((m) => `
        <tr>
          <td>${m.id}</td><td>${m.name}</td><td>${m.email}</td><td>${m.type}</td><td>${m.books_issued}</td>
          <td><span class="badge badge-${m.status.toLowerCase()}">${m.status}</span></td>
          <td>
            <button class="icon-btn" onclick="App.openMemberModal('${m.id}')">✏️</button>
            <button class="icon-btn" onclick="App.deleteMember('${m.id}')">🗑️</button>
          </td>
        </tr>`).join('');
    document.getElementById('membersTableBody').innerHTML = rows || '<tr><td colspan="7">No members found</td></tr>';
  },

  openMemberModal(id) {
    this.editing.memberId = id || null;
    const member = id ? this.state.members.find((m) => m.id === id) : null;
    document.getElementById('memberModalTitle').textContent = member ? 'Edit Member' : 'Add Member';
    document.getElementById('memberIdField').value = member ? member.id : '';
    document.getElementById('memberName').value = member ? member.name : '';
    document.getElementById('memberEmail').value = member ? member.email : '';
    document.getElementById('memberType').value = member ? member.type : 'Student';
    document.getElementById('memberStatus').value = member ? member.status : 'Active';
    document.getElementById('memberModal').classList.remove('hidden');
  },

  async saveMember(e) {
    e.preventDefault();
    const id = document.getElementById('memberIdField').value;
    const payload = {
      name: document.getElementById('memberName').value,
      email: document.getElementById('memberEmail').value,
      type: document.getElementById('memberType').value,
      status: document.getElementById('memberStatus').value
    };
    try {
      if (id) {
        await this.apiPut(`/members/${id}`, payload);
        this.showToast('Member updated', 'success');
      } else {
        payload.id = `MB-${Date.now().toString().slice(-6)}`;
        payload.joined = new Date().toISOString().split('T')[0];
        payload.books_issued = 0;
        await this.apiPost('/members', payload);
        this.showToast('Member registered', 'success');
      }
      document.getElementById('memberModal').classList.add('hidden');
      await this.refreshAll();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  async deleteMember(id) {
    if (!confirm('Remove this member?')) return;
    try {
      await this.apiDelete(`/members/${id}`);
      this.showToast('Member removed', 'success');
      await this.refreshAll();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // ---------- Circulation ----------
  renderCirculation() {
    const availableBooks = this.state.books.filter((b) => b.status === 'Available');
    const activeMembers = this.state.members.filter((m) => m.status === 'Active');
    const activeLoans = this.state.transactions.filter((t) => t.status !== 'Returned');

    document.getElementById('issueBookSelect').innerHTML =
      availableBooks.map((b) => `<option value="${b.id}">${b.title} (${b.id})</option>`).join('') ||
      '<option disabled>No books available</option>';
    document.getElementById('issueMemberSelect').innerHTML =
      activeMembers.map((m) => `<option value="${m.id}">${m.name} (${m.id})</option>`).join('') ||
      '<option disabled>No active members</option>';
    document.getElementById('returnTxnSelect').innerHTML =
      activeLoans.map((t) => `<option value="${t.id}">${t.book_title} → ${t.member_name} (${t.id})</option>`).join('') ||
      '<option disabled>No active loans</option>';

    document.getElementById('transactionsTableBody').innerHTML = this.state.transactions.map((t) => `
      <tr>
        <td>${t.id}</td><td>${t.book_title}</td><td>${t.member_name}</td>
        <td>${t.issue_date}</td><td>${t.due_date}</td><td>${t.return_date || '—'}</td>
        <td>₹${t.fine}</td>
        <td><span class="badge badge-${t.status.toLowerCase()}">${t.status}</span></td>
      </tr>`).join('') || '<tr><td colspan="8">No transactions yet</td></tr>';
  },

  async handleIssueSubmit(e) {
    e.preventDefault();
    const bookId = document.getElementById('issueBookSelect').value;
    const memberId = document.getElementById('issueMemberSelect').value;
    const book = this.state.books.find((b) => b.id === bookId);
    const member = this.state.members.find((m) => m.id === memberId);
    if (!book || !member) return this.showToast('Select a valid book and member', 'error');

    try {
      await this.apiPost('/transactions', {
        id: `TXN-${Date.now().toString().slice(-6)}`,
        book_id: book.id,
        book_title: book.title,
        member_id: member.id,
        member_name: member.name,
        issue_date: document.getElementById('issueDate').value,
        due_date: document.getElementById('dueDate').value
      });
      this.showToast('Book checked out successfully', 'success');
      e.target.reset();
      await this.refreshAll();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  async handleReturnSubmit(e) {
    e.preventDefault();
    const txnId = document.getElementById('returnTxnSelect').value;
    if (!txnId) return this.showToast('Select a loan to return', 'error');
    try {
      const result = await this.apiPost('/transactions/return', { txn_id: txnId });
      this.showToast(result.fine > 0 ? `Returned — fine of ₹${result.fine} applied` : 'Book returned successfully', 'success');
      await this.refreshAll();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // ---------- Settings ----------
  async downloadBackup() {
    try {
      const backup = await this.apiGet('/backup/download');
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `librisync-backup-${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  async restoreBackup(file) {
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      await this.apiPost('/backup/restore', data);
      this.showToast('Backup restored', 'success');
      await this.refreshAll();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  async resetDatabase() {
    if (!confirm('This will erase all current data and reseed sample data. Continue?')) return;
    try {
      await this.apiPost('/database/reset');
      this.showToast('Database reset', 'success');
      await this.refreshAll();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // ---------- Forms & events ----------
  initForms() {
    document.getElementById('addBookBtn').addEventListener('click', () => this.openBookModal(null));
    document.getElementById('cancelBookBtn').addEventListener('click', () => document.getElementById('bookModal').classList.add('hidden'));
    document.getElementById('bookForm').addEventListener('submit', (e) => this.saveBook(e));

    document.getElementById('addMemberBtn').addEventListener('click', () => this.openMemberModal(null));
    document.getElementById('cancelMemberBtn').addEventListener('click', () => document.getElementById('memberModal').classList.add('hidden'));
    document.getElementById('memberForm').addEventListener('submit', (e) => this.saveMember(e));

    document.getElementById('bookSearch').addEventListener('input', (e) => this.renderBooks(e.target.value));
    document.getElementById('memberSearch').addEventListener('input', (e) => this.renderMembers(e.target.value));

    document.getElementById('issueForm').addEventListener('submit', (e) => this.handleIssueSubmit(e));
    document.getElementById('returnForm').addEventListener('submit', (e) => this.handleReturnSubmit(e));

    document.getElementById('downloadBackupBtn').addEventListener('click', () => this.downloadBackup());
    document.getElementById('restoreFileInput').addEventListener('change', (e) => {
      if (e.target.files[0]) this.restoreBackup(e.target.files[0]);
    });
    document.getElementById('resetDbBtn').addEventListener('click', () => this.resetDatabase());

    document.getElementById('saveApiBaseBtn').addEventListener('click', () => {
      this.API_BASE = document.getElementById('apiBaseInput').value.trim();
      localStorage.setItem('librisync_api_base', this.API_BASE);
      this.showToast('API base URL saved', 'success');
      this.refreshAll();
    });
  },

  showToast(msg, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.className = `toast show ${type === 'error' ? 'error' : ''}`;
    setTimeout(() => toast.classList.remove('show'), 3000);
  }
};

document.addEventListener('DOMContentLoaded', () => App.init());
