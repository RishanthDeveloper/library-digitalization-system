# LibriSync — Library Management System

A full-stack library management system with a **completely separate frontend and backend**, ready to push to GitHub.

- **Backend** — Node.js, Express, SQLite (REST API)
- **Frontend** — Vanilla HTML, CSS, JavaScript (no build step, no framework)

## Project Structure

```
library-management-system/
├── backend/
│   ├── server.js         # Express REST API + SQLite persistence
│   ├── package.json
│   └── .gitignore
├── frontend/
│   ├── index.html        # Multi-view SPA (Dashboard, Books, Members, Circulation, Activity, Settings)
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── app.js        # Talks to the backend via fetch()
└── README.md
```

## Features

- **Dashboard** — live stats: total books, available books, active members, overdue loans, pending fines
- **Books** — add, edit, delete, search catalog
- **Members** — add, edit, delete, search members
- **Circulation** — issue and return books, automatic overdue detection and ₹5/day fine calculation
- **Activity Log** — every action is timestamped and recorded
- **Settings** — download/restore a full JSON backup, reset the database, change the backend URL

## Running Locally

### 1. Backend

```bash
cd backend
npm install
npm start
```

The API runs on `http://localhost:3000`. A `librisync.db` SQLite file is created automatically and seeded with sample books, members, and transactions on first run.

### 2. Frontend

The frontend is static — no build step required. You can:

- Open `frontend/index.html` directly in a browser, **or**
- Serve it with any static server, e.g.:

```bash
cd frontend
npx serve .
```

By default the frontend calls the API at `http://localhost:3000/api`. If your backend runs elsewhere, open the **Settings** tab in the app and update the "Backend URL" field (saved in the browser automatically).

> Note: `cors()` is already enabled on the backend, so the frontend can be hosted on a different origin/port than the API.

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/books` | List all books |
| POST | `/api/books` | Add a book |
| PUT | `/api/books/:id` | Update a book |
| DELETE | `/api/books/:id` | Delete a book (blocked while issued) |
| GET | `/api/members` | List all members |
| POST | `/api/members` | Register a member |
| PUT | `/api/members/:id` | Update a member |
| DELETE | `/api/members/:id` | Remove a member (blocked while they hold loans) |
| GET | `/api/transactions` | List all circulation transactions |
| POST | `/api/transactions` | Issue a book to a member |
| POST | `/api/transactions/return` | Return a book, auto-calculates fine |
| GET | `/api/dashboard/stats` | Aggregate dashboard counters |
| GET | `/api/activities` | Recent activity log |
| GET | `/api/notifications` | Notifications list |
| POST | `/api/notifications/clear` | Clear all notifications |
| GET | `/api/theme` | Get saved theme config |
| POST | `/api/theme` | Save theme config |
| GET | `/api/backup/download` | Download a full JSON backup |
| POST | `/api/backup/restore` | Restore from a JSON backup |
| POST | `/api/database/reset` | Wipe and reseed the database |

## Publishing to GitHub

```bash
cd library-management-system
git init
git add .
git commit -m "Initial commit: LibriSync library management system"
git branch -M main
git remote add origin https://github.com/RishanthDeveloper/library-management-system.git
git push -u origin main
```

`backend/.gitignore` already excludes `node_modules/` and the generated `librisync.db` file, so your repo stays clean.

## Tech Stack

- **Backend:** Node.js, Express, sqlite3, cors
- **Frontend:** HTML5, CSS3, vanilla JavaScript (Fetch API)

## License

MIT
