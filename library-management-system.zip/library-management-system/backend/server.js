const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'librisync.db');

app.use(cors());
app.use(express.json());

// ==================== Database Connection ====================
const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('Database connection error:', err.message);
  } else {
    console.log('Connected to SQLite database at:', DB_PATH);
    initializeDatabase();
  }
});

// ==================== Schema + Seed ====================
function initializeDatabase() {
  db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS books (
      id TEXT PRIMARY KEY,
      isbn TEXT NOT NULL,
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      category TEXT NOT NULL,
      publisher TEXT,
      year INTEGER,
      rack TEXT,
      status TEXT DEFAULT 'Available',
      cover_url TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS members (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      type TEXT NOT NULL,
      joined TEXT NOT NULL,
      books_issued INTEGER DEFAULT 0,
      status TEXT DEFAULT 'Active'
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      book_id TEXT NOT NULL,
      book_title TEXT NOT NULL,
      member_id TEXT NOT NULL,
      member_name TEXT NOT NULL,
      issue_date TEXT NOT NULL,
      due_date TEXT NOT NULL,
      return_date TEXT,
      fine REAL DEFAULT 0,
      status TEXT DEFAULT 'Issued'
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      time TEXT NOT NULL
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      msg TEXT NOT NULL,
      time TEXT NOT NULL,
      read INTEGER DEFAULT 0
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS theme (
      id INTEGER PRIMARY KEY DEFAULT 1,
      darkMode INTEGER DEFAULT 0,
      accentColor TEXT DEFAULT '#2563EB'
    )`);

    db.get('SELECT COUNT(*) as count FROM books', (err, row) => {
      if (!err && row.count === 0) {
        console.log('Seeding database with sample data...');
        seedMockDatabase();
      }
    });
  });
}

function seedMockDatabase() {
  const books = [
    ['BK-001', '9780743273565', 'The Great Gatsby', 'F. Scott Fitzgerald', 'Fiction', 'Scribner', 1925, 'A-1', 'Available', ''],
    ['BK-002', '9780553380163', 'A Brief History of Time', 'Stephen Hawking', 'Science', 'Bantam Books', 1988, 'B-3', 'Available', ''],
    ['BK-003', '9780062316097', 'Sapiens', 'Yuval Noah Harari', 'History', 'Harper', 2011, 'C-2', 'Issued', ''],
    ['BK-004', '9781451648539', 'Steve Jobs', 'Walter Isaacson', 'Biography', 'Simon & Schuster', 2011, 'D-1', 'Available', ''],
    ['BK-005', '9780132350884', 'Clean Code', 'Robert C. Martin', 'Technology', 'Prentice Hall', 2008, 'E-4', 'Overdue', ''],
    ['BK-006', '9780140449235', 'Beyond Good and Evil', 'Friedrich Nietzsche', 'Philosophy', 'Penguin Classics', 1886, 'F-1', 'Available', ''],
    ['BK-007', '9780446310789', 'To Kill a Mockingbird', 'Harper Lee', 'Fiction', 'J. B. Lippincott & Co.', 1960, 'A-2', 'Available', ''],
    ['BK-008', '9780345331359', 'Cosmos', 'Carl Sagan', 'Science', 'Random House', 1980, 'B-1', 'Available', ''],
    ['BK-009', '9780393317558', 'Guns, Germs, and Steel', 'Jared Diamond', 'History', 'W. W. Norton & Co.', 1997, 'C-1', 'Available', ''],
    ['BK-010', '9781476708690', 'The Innovators', 'Walter Isaacson', 'Technology', 'Simon & Schuster', 2014, 'E-1', 'Available', '']
  ];

  const members = [
    ['MB-001', 'Alice Smith', 'alice.smith@university.edu', 'Student', '2026-01-15', 1, 'Active'],
    ['MB-002', 'Bob Jones', 'bob.jones@university.edu', 'Faculty', '2025-09-01', 1, 'Active'],
    ['MB-003', 'Charlie Brown', 'charlie.b@gmail.com', 'Guest', '2026-03-10', 0, 'Active'],
    ['MB-004', 'Diana Prince', 'diana.prince@justice.org', 'Student', '2026-02-18', 0, 'Active'],
    ['MB-005', 'Evan Wright', 'evan.wright@outlook.com', 'Guest', '2025-11-20', 0, 'Suspended']
  ];

  const transactions = [
    ['TXN-101', 'BK-003', 'Sapiens', 'MB-001', 'Alice Smith', '2026-06-25', '2026-07-09', null, 0, 'Issued'],
    ['TXN-102', 'BK-005', 'Clean Code', 'MB-002', 'Bob Jones', '2026-06-10', '2026-06-24', null, 45, 'Overdue'],
    ['TXN-103', 'BK-001', 'The Great Gatsby', 'MB-003', 'Charlie Brown', '2026-06-01', '2026-06-15', '2026-06-12', 0, 'Returned'],
    ['TXN-104', 'BK-004', 'Steve Jobs', 'MB-004', 'Diana Prince', '2026-05-15', '2026-05-29', '2026-06-05', 35, 'Returned']
  ];

  const activities = [
    ['System Initialized', new Date().toISOString()],
    ["Book BK-005 'Clean Code' marked OVERDUE", new Date().toISOString()],
    ["Member MB-001 issued book BK-003 'Sapiens'", new Date().toISOString()]
  ];

  const notifications = [
    ['NT-1', "Book 'Clean Code' is overdue for Member Bob Jones.", new Date().toISOString(), 0]
  ];

  const insertBook = db.prepare(`INSERT INTO books VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  books.forEach((b) => insertBook.run(b));
  insertBook.finalize();

  const insertMember = db.prepare(`INSERT INTO members VALUES (?, ?, ?, ?, ?, ?, ?)`);
  members.forEach((m) => insertMember.run(m));
  insertMember.finalize();

  const insertTxn = db.prepare(`INSERT INTO transactions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  transactions.forEach((t) => insertTxn.run(t));
  insertTxn.finalize();

  const insertActivity = db.prepare(`INSERT INTO activities (title, time) VALUES (?, ?)`);
  activities.forEach((a) => insertActivity.run(a));
  insertActivity.finalize();

  const insertNotification = db.prepare(`INSERT INTO notifications VALUES (?, ?, ?, ?)`);
  notifications.forEach((n) => insertNotification.run(n));
  insertNotification.finalize();

  db.run(`INSERT OR IGNORE INTO theme (id, darkMode, accentColor) VALUES (1, 0, '#2563EB')`);
}

// Recalculates overdue status + fines (₹5/day) for active loans, keeps books/members in sync
function recalculateFines(callback) {
  const todayStr = new Date().toISOString().split('T')[0];
  db.all(`SELECT * FROM transactions WHERE status IN ('Issued', 'Overdue')`, [], (err, rows) => {
    if (err) return callback(err);
    const today = new Date(todayStr);
    let pending = rows.length;
    if (pending === 0) return callback(null);

    rows.forEach((txn) => {
      const dueDate = new Date(txn.due_date);
      if (today > dueDate) {
        const diffDays = Math.ceil(Math.abs(today - dueDate) / (1000 * 60 * 60 * 24));
        const fineAmount = diffDays * 5;
        db.run(
          `UPDATE transactions SET fine = ?, status = 'Overdue' WHERE id = ?`,
          [fineAmount, txn.id],
          () => {
            db.run(`UPDATE books SET status = 'Overdue' WHERE id = ? AND status != 'Available'`, [txn.book_id], () => {
              pending -= 1;
              if (pending === 0) callback(null);
            });
          }
        );
      } else {
        pending -= 1;
        if (pending === 0) callback(null);
      }
    });
  });
}

function logActivity(title) {
  db.run(`INSERT INTO activities (title, time) VALUES (?, ?)`, [title, new Date().toISOString()]);
}

// ==================== Books API ====================
app.get('/api/books', (req, res) => {
  recalculateFines(() => {
    db.all('SELECT * FROM books', [], (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    });
  });
});

app.post('/api/books', (req, res) => {
  const { id, isbn, title, author, category, publisher, year, rack, status, cover_url } = req.body;
  if (!id || !title || !author) {
    return res.status(400).json({ error: 'id, title and author are required' });
  }
  const sql = `INSERT INTO books VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
  db.run(sql, [id, isbn, title, author, category, publisher, year, rack, status || 'Available', cover_url || ''], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    logActivity(`Book '${title}' added to catalog`);
    res.json({ message: 'Book added', id });
  });
});

app.put('/api/books/:id', (req, res) => {
  const { isbn, title, author, category, publisher, year, rack, status, cover_url } = req.body;
  const sql = `UPDATE books SET isbn=?, title=?, author=?, category=?, publisher=?, year=?, rack=?, status=?, cover_url=? WHERE id=?`;
  db.run(sql, [isbn, title, author, category, publisher, year, rack, status, cover_url, req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0) return res.status(404).json({ error: 'Book not found' });
    logActivity(`Book '${title}' details updated`);
    res.json({ message: 'Book updated' });
  });
});

app.delete('/api/books/:id', (req, res) => {
  db.get('SELECT * FROM books WHERE id = ?', [req.params.id], (err, book) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!book) return res.status(404).json({ error: 'Book not found' });
    if (book.status !== 'Available') {
      return res.status(400).json({ error: 'Cannot delete a book that is currently issued' });
    }
    db.run('DELETE FROM books WHERE id = ?', [req.params.id], function (err2) {
      if (err2) return res.status(500).json({ error: err2.message });
      logActivity(`Book '${book.title}' removed from catalog`);
      res.json({ message: 'Book deleted' });
    });
  });
});

// ==================== Members API ====================
app.get('/api/members', (req, res) => {
  db.all('SELECT * FROM members', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/members', (req, res) => {
  const { id, name, email, type, joined, books_issued, status } = req.body;
  if (!id || !name || !email) {
    return res.status(400).json({ error: 'id, name and email are required' });
  }
  const sql = `INSERT INTO members VALUES (?, ?, ?, ?, ?, ?, ?)`;
  db.run(sql, [id, name, email, type, joined || new Date().toISOString().split('T')[0], books_issued || 0, status || 'Active'], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    logActivity(`New member '${name}' registered`);
    res.json({ message: 'Member registered', id });
  });
});

app.put('/api/members/:id', (req, res) => {
  const { name, email, type, status } = req.body;
  const sql = `UPDATE members SET name=?, email=?, type=?, status=? WHERE id=?`;
  db.run(sql, [name, email, type, status, req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0) return res.status(404).json({ error: 'Member not found' });
    res.json({ message: 'Member updated' });
  });
});

app.delete('/api/members/:id', (req, res) => {
  db.get('SELECT * FROM members WHERE id = ?', [req.params.id], (err, member) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!member) return res.status(404).json({ error: 'Member not found' });
    if (member.books_issued > 0) {
      return res.status(400).json({ error: 'Cannot remove a member with active loans' });
    }
    db.run('DELETE FROM members WHERE id = ?', [req.params.id], function (err2) {
      if (err2) return res.status(500).json({ error: err2.message });
      logActivity(`Member '${member.name}' removed`);
      res.json({ message: 'Member removed' });
    });
  });
});

// ==================== Circulation (Transactions) API ====================
app.get('/api/transactions', (req, res) => {
  recalculateFines(() => {
    db.all('SELECT * FROM transactions ORDER BY issue_date DESC', [], (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    });
  });
});

app.post('/api/transactions', (req, res) => {
  const { id, book_id, book_title, member_id, member_name, issue_date, due_date } = req.body;

  db.get('SELECT * FROM books WHERE id = ?', [book_id], (err, book) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!book) return res.status(404).json({ error: 'Book not found' });
    if (book.status !== 'Available') return res.status(400).json({ error: 'Book is not available for issue' });

    db.get('SELECT * FROM members WHERE id = ?', [member_id], (err2, member) => {
      if (err2) return res.status(500).json({ error: err2.message });
      if (!member) return res.status(404).json({ error: 'Member not found' });
      if (member.status !== 'Active') return res.status(400).json({ error: 'Member is not active' });

      db.serialize(() => {
        db.run(
          `INSERT INTO transactions VALUES (?, ?, ?, ?, ?, ?, ?, NULL, 0, 'Issued')`,
          [id, book_id, book_title, member_id, member_name, issue_date, due_date]
        );
        db.run(`UPDATE books SET status = 'Issued' WHERE id = ?`, [book_id]);
        db.run(`UPDATE members SET books_issued = books_issued + 1 WHERE id = ?`, [member_id]);
        logActivity(`Checked out '${book_title}' to member '${member_name}'`);
      });

      res.json({ message: 'Book checked out successfully', id });
    });
  });
});

app.post('/api/transactions/return', (req, res) => {
  const { txn_id } = req.body;

  db.get('SELECT * FROM transactions WHERE id = ?', [txn_id], (err, txn) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!txn) return res.status(404).json({ error: 'Transaction not found' });
    if (txn.status === 'Returned') return res.status(400).json({ error: 'Book already returned' });

    const returnDate = new Date().toISOString().split('T')[0];
    const dueDate = new Date(txn.due_date);
    const today = new Date(returnDate);
    let fine = 0;
    if (today > dueDate) {
      const diffDays = Math.ceil(Math.abs(today - dueDate) / (1000 * 60 * 60 * 24));
      fine = diffDays * 5;
    }

    db.serialize(() => {
      db.run(`UPDATE transactions SET return_date = ?, fine = ?, status = 'Returned' WHERE id = ?`, [returnDate, fine, txn_id]);
      db.run(`UPDATE books SET status = 'Available' WHERE id = ?`, [txn.book_id]);
      db.run(`UPDATE members SET books_issued = MAX(0, books_issued - 1) WHERE id = ?`, [txn.member_id]);
      logActivity(`Book check-in returned: '${txn.book_title}'`);
    });

    res.json({ message: 'Book returned successfully', fine });
  });
});

// ==================== Dashboard Stats ====================
app.get('/api/dashboard/stats', (req, res) => {
  recalculateFines(() => {
    const stats = {};
    db.get(`SELECT COUNT(*) as total FROM books`, [], (e1, r1) => {
      stats.totalBooks = r1.total;
      db.get(`SELECT COUNT(*) as total FROM books WHERE status = 'Available'`, [], (e2, r2) => {
        stats.availableBooks = r2.total;
        db.get(`SELECT COUNT(*) as total FROM members WHERE status = 'Active'`, [], (e3, r3) => {
          stats.activeMembers = r3.total;
          db.get(`SELECT COUNT(*) as total FROM transactions WHERE status = 'Overdue'`, [], (e4, r4) => {
            stats.overdueBooks = r4.total;
            db.get(`SELECT COALESCE(SUM(fine), 0) as total FROM transactions WHERE status = 'Overdue'`, [], (e5, r5) => {
              stats.pendingFines = r5.total;
              res.json(stats);
            });
          });
        });
      });
    });
  });
});

// ==================== Activity Log API ====================
app.get('/api/activities', (req, res) => {
  db.all('SELECT * FROM activities ORDER BY id DESC LIMIT 50', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// ==================== Notifications API ====================
app.get('/api/notifications', (req, res) => {
  db.all('SELECT * FROM notifications ORDER BY time DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows.map((r) => ({ ...r, read: !!r.read })));
  });
});

app.post('/api/notifications/clear', (req, res) => {
  db.run('DELETE FROM notifications', [], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Notifications cleared' });
  });
});

// ==================== Theme Config API ====================
app.get('/api/theme', (req, res) => {
  db.get('SELECT * FROM theme WHERE id = 1', [], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.json({ darkMode: false, accentColor: '#2563EB' });
    res.json({ darkMode: !!row.darkMode, accentColor: row.accentColor });
  });
});

app.post('/api/theme', (req, res) => {
  const { darkMode, accentColor } = req.body;
  db.run(`UPDATE theme SET darkMode = ?, accentColor = ? WHERE id = 1`, [darkMode ? 1 : 0, accentColor], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Theme updated' });
  });
});

// ==================== Database Utilities ====================
app.post('/api/database/reset', (req, res) => {
  db.serialize(() => {
    db.run('DELETE FROM books');
    db.run('DELETE FROM members');
    db.run('DELETE FROM transactions');
    db.run('DELETE FROM activities');
    db.run('DELETE FROM notifications');
    db.run('DELETE FROM theme');
    seedMockDatabase();
    setTimeout(() => res.json({ message: 'Database reset successful' }), 400);
  });
});

app.get('/api/backup/download', (req, res) => {
  const backup = {};
  db.all('SELECT * FROM books', [], (e1, books) => {
    backup.books = books;
    db.all('SELECT * FROM members', [], (e2, members) => {
      backup.members = members;
      db.all('SELECT * FROM transactions', [], (e3, transactions) => {
        backup.transactions = transactions;
        db.all('SELECT * FROM activities', [], (e4, activities) => {
          backup.activities = activities;
          db.all('SELECT * FROM notifications', [], (e5, notifications) => {
            backup.notifications = notifications;
            db.get('SELECT * FROM theme WHERE id = 1', [], (e6, theme) => {
              backup.theme = theme ? { darkMode: !!theme.darkMode, accentColor: theme.accentColor } : { darkMode: false, accentColor: '#2563EB' };
              backup.exportedAt = new Date().toISOString();
              res.json(backup);
            });
          });
        });
      });
    });
  });
});

app.post('/api/backup/restore', (req, res) => {
  const { books, members, transactions, activities, notifications, theme } = req.body;

  db.serialize(() => {
    db.run('DELETE FROM books');
    db.run('DELETE FROM members');
    db.run('DELETE FROM transactions');
    db.run('DELETE FROM activities');
    db.run('DELETE FROM notifications');
    db.run('DELETE FROM theme');

    if (books) {
      const stmt = db.prepare(`INSERT INTO books VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
      books.forEach((b) => stmt.run([b.id, b.isbn, b.title, b.author, b.category, b.publisher, b.year, b.rack, b.status, b.cover_url]));
      stmt.finalize();
    }
    if (members) {
      const stmt = db.prepare(`INSERT INTO members VALUES (?, ?, ?, ?, ?, ?, ?)`);
      members.forEach((m) => stmt.run([m.id, m.name, m.email, m.type, m.joined, m.books_issued, m.status]));
      stmt.finalize();
    }
    if (transactions) {
      const stmt = db.prepare(`INSERT INTO transactions VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
      transactions.forEach((t) => stmt.run([t.id, t.book_id, t.book_title, t.member_id, t.member_name, t.issue_date, t.due_date, t.return_date, t.fine, t.status]));
      stmt.finalize();
    }
    if (activities) {
      const stmt = db.prepare(`INSERT INTO activities (title, time) VALUES (?, ?)`);
      activities.forEach((a) => stmt.run([a.title, a.time]));
      stmt.finalize();
    }
    if (notifications) {
      const stmt = db.prepare(`INSERT INTO notifications VALUES (?, ?, ?, ?)`);
      notifications.forEach((n) => stmt.run([n.id, n.msg, n.time, n.read ? 1 : 0]));
      stmt.finalize();
    }
    if (theme) db.run(`INSERT INTO theme (id, darkMode, accentColor) VALUES (1, ?, ?)`, [theme.darkMode ? 1 : 0, theme.accentColor]);

    setTimeout(() => res.json({ message: 'Database restored successfully' }), 400);
  });
});

app.listen(PORT, () => {
  console.log(`LibriSync backend server running on http://localhost:${PORT}`);
});
